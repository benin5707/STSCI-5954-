# Verification record

## Executed workflow

1. Compiled all Python modules and numbered scripts.
2. Ran scripts/01_fit_clusters.py on the included raw CSV.
3. Ran run_all.py --skip-fit --include-demo to generate figures, English
   documentation, and demonstration predictions.
4. Redrew the comparison figure after setting discrete cluster-count ticks.
5. Ran the prediction entry point from outside the repository working directory.

## Data and numerical checks

- Exactly nine formal candidates are present:
  original/PCA80/PCA90 crossed with k=5/6/7, all using K-means.
- The validation grid and combined comparison each have nine rows.
- Each candidate has five stability repeats; the repeat table has 45 rows.
- The elbow table has 30 training-only diagnostics (k=1–10 for each
  representation), with exactly nine marked as formal comparison candidates.
- All nine validation scores, supporting metrics, and size checks match the
  corresponding prior results within absolute/relative tolerances of 1e-10.
- The selected specification remains original standardized nine-dimensional
  K-means with six groups.
- The selected-model test scores, all 28,356 delivery assignments, split
  manifest, original memberships, and cluster profiles match the prior baseline.
- The supplied six-song demonstration predictions match exactly.
- Raw data, example input, and client brief are preserved byte-for-byte.
- No other clustering algorithm remains in the executable source.

## Documentation and packaging checks

- README shows all nine configurations with dimensions, silhouette, DB, CH,
  mean stability ARI, and selected/eligible status.
- README includes the actual training PCA component counts, individual and
  cumulative variance, and the separate role of the descriptive projection.
- Elbow interpretation is stated as diagnostic rather than a unique,
  automatically established choice of k=6.
- The focused candidate range is described as a follow-up, not retroactively
  presented as the original search plan.
- Model-comparison and elbow figures were visually reviewed.
- Local document links and image paths were checked.
- Documentation, filenames, and code comments were checked for untranslated
  Chinese prose; original source metadata are preserved.
- ZIP integrity was checked. Temporary files, caches, and test-run directories
  are excluded from the delivery.

These checks establish reproducible computation and packaging. They do not
supply new independent test data, listener-confirmed mood categories, or
completed client listening feedback.

